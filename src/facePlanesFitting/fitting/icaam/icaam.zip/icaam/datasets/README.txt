For space constraints reason, these aren't included. 
Go to the sourceforge page (http://sourceforge.net/projects/icaam/files/) to get the latest complete version of the software.